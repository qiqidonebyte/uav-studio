import { createRouter, createWebHistory } from 'vue-router'
import Assembly from '../views/Assembly.vue'
import FlightLab from '../views/FlightLab.vue'
import History from '../views/History.vue'
import ComponentLibrary from '../views/ComponentLibrary.vue'
import Settings from '../views/Settings.vue'

export const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', redirect: '/assembly' },
    { path: '/assembly', component: Assembly },
    { path: '/flight', component: FlightLab },
    { path: '/history', component: History },
    { path: '/components', component: ComponentLibrary },
    { path: '/settings', component: Settings },
  ],
})
