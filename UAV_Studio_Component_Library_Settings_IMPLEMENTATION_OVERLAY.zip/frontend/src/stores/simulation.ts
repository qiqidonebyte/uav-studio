import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import type { TelemetryFrame } from '../types/telemetry'

const massKg = 4.12
const gravityN = massKg * 9.81

const demoFrame: TelemetryFrame = {
  t: 32.4,
  position: { x: 2.3, y: 0.6, z: 10.0 },
  velocity: { x: 0.12, y: -0.08, z: 0.01 },
  attitude: { roll: -0.01396, pitch: 0.02094, yaw: 1.5638 },
  angular_velocity: { p: 0.01, q: -0.02, r: 0.0 },
  center_of_gravity: { x: 0.015, y: 0.0, z: -0.028 },
  motors: { outputs: [0.691, 0.667, 0.681, 0.671], thrusts_n: [10.5, 9.8, 10.2, 9.9] },
  forces: { gravity_n: gravityN, total_thrust_n: 40.4 },
  wind: { speed_mps: 5, direction_deg: 90 },
  power: { estimated_power_w: 570, battery_remaining: 0.86, voltage_v: 22.2, current_a: 25.7 },
  armed: true,
  flight_mode: 'HOVERING'
}

const statusZh: Record<string, string> = { RUNNING:'运行中', STOPPED:'已停止', PAUSED:'已暂停' }
const modeZh: Record<string, string> = { IDLE:'待机', ARMED:'已解锁', TAKING_OFF:'起飞中', HOVERING:'悬停', LANDING:'降落中' }

export const useSimulationStore = defineStore('simulation', () => {
  const telemetry = ref<TelemetryFrame>(demoFrame)
  const history = ref<TelemetryFrame[]>([demoFrame])
  const simulationStatus = ref<'STOPPED' | 'RUNNING' | 'PAUSED'>('RUNNING')
  const aircraftName = ref('EduQuad-650')
  const targetAltitude = ref(10)
  const windSpeed = ref(5)
  const windDirection = ref(90)
  const ws = ref<WebSocket | null>(null)

  const airborne = computed(() => telemetry.value.position.z > 0.2)
  const batteryPercent = computed(() => Math.round(telemetry.value.power.battery_remaining * 100))
  const simulationStatusZh = computed(() => statusZh[simulationStatus.value] ?? simulationStatus.value)
  const flightModeZh = computed(() => modeZh[telemetry.value.flight_mode] ?? telemetry.value.flight_mode)

  function setTelemetry(frame: TelemetryFrame) {
    telemetry.value = frame
    history.value.push(frame)
    if (history.value.length > 1200) history.value.splice(0, history.value.length - 1200)
  }

  function connectTelemetry(url: string) {
    ws.value?.close()
    const socket = new WebSocket(url)
    ws.value = socket
    socket.onmessage = (event) => setTelemetry(JSON.parse(event.data) as TelemetryFrame)
    socket.onclose = () => { ws.value = null }
  }

  function disconnectTelemetry() { ws.value?.close(); ws.value = null }

  return { telemetry, history, simulationStatus, aircraftName, targetAltitude, windSpeed, windDirection, airborne, batteryPercent, simulationStatusZh, flightModeZh, setTelemetry, connectTelemetry, disconnectTelemetry }
})
