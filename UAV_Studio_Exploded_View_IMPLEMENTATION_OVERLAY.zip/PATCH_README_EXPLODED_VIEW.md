# UAV Studio — 爆炸视图实现包

基线：GitHub `qiqidonebyte/uav-studio` main，HEAD：

`df88d9e3e4cb02138cbda1cbf631c7fdc2bad4d2`

本包只修改 3D 装配相关代码和测试，不覆盖组件库、系统设置、后端或你的其他页面。

## 新功能

装配页中央 3D 工具栏增加：

- 整机
- 爆炸视图
- 俯视
- 侧视
- 自由

飞行 3D 工具栏保持原来的跟随 / 俯视 / 侧视 / 自由。

爆炸视图按装配层级展开：
GNSS / 飞控向上，动力组向外，电池 / 电源 / 载荷向下，机架固定。

原来长期悬浮的 M1-M4 顺/逆时针文字被收敛：
只有“螺旋桨”步骤的整机模式才显示；爆炸模式不显示。

## 覆盖文件

- frontend/src/components/DroneScene.vue
- frontend/src/three/AircraftRenderer.ts
- frontend/src/three/explodedView.ts
- frontend/src/types/visual-test.d.ts
- frontend/tests/exploded-view.test.ts
- frontend/tests/p0-scene-contract.mjs
- frontend/tests/p0-visual-capture.mjs
- tools/verify_exploded_view.py
- docs/15_EXPLODED_VIEW_SPEC_CN.md
- docs/16_EXPLODED_VIEW_TEST_PLAN.md

## 推荐完整回归

覆盖到你的最新项目后：

```bash
cd frontend
npm run build
npm run test
npm run test:p0:scene
npm run test:p0:capture
npm run e2e
npm run e2e:flight
```

`test:p0:capture` 生成的爆炸视图截图先作为 candidate，不自动设为 Golden。
