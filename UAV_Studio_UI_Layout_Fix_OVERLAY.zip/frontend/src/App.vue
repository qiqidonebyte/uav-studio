<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="brand brand-campus">
        <img
          class="campus-mark"
          src="/branding/zjitc-campus-mark.svg"
          alt="浙江工贸"
        />
        <div class="brand-copy">
          <div class="brand-mainline">
            <strong>UAV Studio</strong>
            <span>浙江工贸</span>
          </div>
          <small>无人机数字设计与飞行验证平台</small>
        </div>
      </div>

      <nav>
        <RouterLink to="/assembly">无人机装配</RouterLink>
        <RouterLink to="/flight">飞行实验</RouterLink>
        <RouterLink to="/history">实验记录</RouterLink>
      </nav>

      <div class="top-status">
        <span class="aircraft-chip">{{ assemblyStore.aircraftName }}</span>
        <span class="status-pill info">{{ store.simulationStatusZh }}</span>
      </div>
    </header>
    <RouterView />
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { useAssemblyStore } from './stores/assembly'
import { useSimulationStore } from './stores/simulation'

const store = useSimulationStore()
const assemblyStore = useAssemblyStore()

onMounted(() => {
  void assemblyStore.initialize()
})
</script>

<style scoped>
.brand-campus {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 8px;
}

.campus-mark {
  display: block;
  width: 28px;
  height: 28px;
  flex: 0 0 28px;
  border-radius: 7px;
}

.brand-copy {
  min-width: 0;
  display: grid;
  gap: 1px;
}

.brand-mainline {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 6px;
}

.brand-mainline strong {
  color: #f8fbff;
  font-size: 16px;
  line-height: 18px;
  font-weight: 800;
  letter-spacing: -0.02em;
  white-space: nowrap;
}

.brand-mainline span {
  flex: 0 0 auto;
  padding: 1px 6px;
  border-radius: 999px;
  border: 1px solid rgba(98, 205, 238, 0.24);
  background: rgba(51, 179, 222, 0.12);
  color: #8ae8ff;
  font-size: 9px;
  line-height: 15px;
  font-weight: 700;
}

.brand-copy small {
  display: block;
  min-width: 0;
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: rgba(222, 233, 249, 0.72);
  font-size: 9px;
  line-height: 12px;
  font-weight: 500;
}
</style>
