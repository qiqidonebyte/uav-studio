<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="brand brand-campus">
        <img
          class="campus-mark"
          src="/branding/zjitc-campus-mark.svg"
          alt="浙江工贸标记"
        />
        <div class="brand-copy">
          <div class="brand-title-row">
            <strong>UAV Studio</strong>
            <span class="brand-campus-tag">浙江工贸</span>
          </div>
          <small>浙江工贸职业技术学院 · 无人机数字设计与飞行验证平台</small>
        </div>
      </div>

      <nav>
        <RouterLink to="/assembly">无人机装配</RouterLink>
        <RouterLink to="/flight">飞行实验</RouterLink>
        <RouterLink to="/history">实验记录</RouterLink>
      </nav>

      <div class="top-status">
        <span class="aircraft-chip">{{ store.aircraftName }}</span>
        <span class="status-pill ok">● {{ store.simulationStatusZh }}</span>
        <span class="status-pill info">{{ store.flightModeZh }}</span>
      </div>
    </header>
    <RouterView />
  </div>
</template>

<script setup lang="ts">
import { useSimulationStore } from './stores/simulation'
const store = useSimulationStore()
</script>

<style scoped>
.brand-campus {
  display: flex;
  align-items: center;
  min-width: 0;
  gap: 10px;
}

.campus-mark {
  width: 36px;
  height: 36px;
  flex: 0 0 36px;
  border-radius: 10px;
  box-shadow: 0 6px 20px rgba(2, 12, 27, 0.18);
}

.brand-copy {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.brand-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}

.brand-title-row strong {
  color: #f8fbff;
  font-size: 19px;
  font-weight: 800;
  letter-spacing: -0.03em;
  white-space: nowrap;
}

.brand-campus-tag {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  border-radius: 999px;
  background: rgba(81, 217, 255, 0.14);
  border: 1px solid rgba(81, 217, 255, 0.22);
  color: #7fe5ff;
  font-size: 10px;
  font-weight: 700;
  white-space: nowrap;
}

.brand-copy small {
  display: block;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: rgba(221, 232, 251, 0.74);
  font-size: 10px;
  font-weight: 500;
}
</style>
